#!/bin/bash

# sleep until instance is ready
until [[ -f /var/lib/cloud/instance/boot-finished ]]; do
  sleep 1
done

# install Apache
sudo yum update
sudo yum install -y httpd
sudo chkconfig httpd on
sudo service httpd start
echo "<h1>Hello from </h1>" ${aws_instance.example.public_ip} | sudo tee /var/www/html/index.html

# make sure apache is started
service httpd start
